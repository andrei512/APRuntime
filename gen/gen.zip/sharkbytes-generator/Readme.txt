get_mobile_metadata - shell script taht take one argument, the name of the destination file for the mobile metadata, if none given it will output to stdout the file
generator.rb 
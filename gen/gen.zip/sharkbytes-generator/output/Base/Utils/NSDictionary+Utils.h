//
//  NSDictionary+Utils.h
//  Point2Homes
//
//  Created by Andrei Puni on 5/6/13.
//  Copyright (c) 2013 Point2. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Utils)

- (NSMutableDictionary *)merge:(NSDictionary *)dict;

@end

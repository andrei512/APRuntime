
//
//  MAAPIConfig.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAAPIConfig.h"

@implementation MAAPIConfig

+ (instancetype)shared {
	static MAAPIConfig *shared = nil;
	if (shared == nil) {
		shared = [MAAPIConfig new];
	}
	return shared;
}

- (NSString *)apiKey {
	return @"AB3ECB14-DCBC-11E1-95F3-9069F59CDCA0";
}

- (NSString *)serverBaseUrl {
	return @"http://m-api.sharketyprop.com/services";
}

@end
//
//  Point2APIClient.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MALocationService.h"
#import "MAListingsService.h"
#import "MAAgentsService.h"
#import "MAAppConfigService.h"


// Search criteria

#define kIs @"is"
#define kLt @"lt"
#define kLte @"lte"
#define kGt @"gt"
#define kGte @"gte"
#define kRange @"range"
#define kRegex @"regex"


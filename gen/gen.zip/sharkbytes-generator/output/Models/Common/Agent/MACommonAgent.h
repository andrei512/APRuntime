
//
//  MACommonAgent.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"

#import "MACommonListingInfo.h"


@interface MACommonAgent : Model


//  Flag if 1 then the agent s email is a valid one
@property (nonatomic, strong) NSNumber *canUseEmail;

//  Unique identifier of an agent s photo
@property (nonatomic, strong) NSNumber *photoId;

//  The agent s website s url
@property (nonatomic, strong) NSString *website;

//  Flag If set to 1 means that the agent is a point2 agent
@property (nonatomic, strong) NSNumber *isPoint2Agent;

//  The name of the agent
@property (nonatomic, strong) NSString *name;

//  A list of agent s phones like personal phone office phone and fax
@property (nonatomic, strong) NSDictionary *phones;

//  The email of the agent
@property (nonatomic, strong) NSString *email;

//  Basic information about brokerage such as company name address phone
//  logo and url
@property (nonatomic, strong) NSDictionary *brokerage;

//  URL with the profile of the agent from Point2 agent application
@property (nonatomic, strong) NSString *point2ProfileUrl;

//  The number of active listings belonging to this agent
@property (nonatomic, strong) NSNumber *listingsCount;

//  Active listings that have as agent the current agent
@property (nonatomic, strong) NSArray *listings;

//  The blogs number of the agent
@property (nonatomic, strong) NSNumber *blogsCount;

//  Unique identifier of an agent
@property (nonatomic, strong) NSNumber *id;

//  Flag when set to 1 means that the agent is a featured one
@property (nonatomic, strong) NSNumber *isFeatured;



@end


//
//  MACommonAgent.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonAgent.h"
#import "NSArray+Utils.h"

@implementation MACommonAgent 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"canUseEmail",
            @"json_name" : @"can_use_email"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"photoId",
            @"json_name" : @"photo_id"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"website",
            @"json_name" : @"website"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"isPoint2Agent",
            @"json_name" : @"is_point2_agent"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"name",
            @"json_name" : @"name"
        },
        @{
            @"of" : @"Item",
            @"type" : @"NSDictionary",
            @"name" : @"phones",
            @"json_name" : @"phones"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"email",
            @"json_name" : @"email"
        },
        @{
            @"of" : @"Item",
            @"type" : @"NSDictionary",
            @"name" : @"brokerage",
            @"json_name" : @"brokerage"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"point2ProfileUrl",
            @"json_name" : @"point2_profile_url"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"listingsCount",
            @"json_name" : @"listings_count"
        },
        @{
            @"of" : @{
                @"of" : @"MACommonListingInfo",
                @"type" : @"NSDictionary"
            },
            @"type" : @"NSArray",
            @"name" : @"listings",
            @"json_name" : @"listings"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"blogsCount",
            @"json_name" : @"blogs_count"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"id",
            @"json_name" : @"id"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"isFeatured",
            @"json_name" : @"is_featured"
        }
    ];
}


@end


//
//  MACommonAgentPhones.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonAgentPhones.h"
#import "NSArray+Utils.h"

@implementation MACommonAgentPhones 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"office",
            @"json_name" : @"office"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"fax",
            @"json_name" : @"fax"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"personal",
            @"json_name" : @"personal"
        }
    ];
}


@end


//
//  MACommonAttachment.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonAttachment : Model


//  String The attachment url
@property (nonatomic, strong) NSString *url;

//  String Used as text for the url eg _ View Attachment _ or _ View Listing
//  Brochure _ If the field is not populated the default value is _ View
//  Attachment _
@property (nonatomic, strong) NSString *linkText;



@end

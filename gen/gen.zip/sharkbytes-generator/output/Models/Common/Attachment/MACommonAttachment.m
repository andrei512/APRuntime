
//
//  MACommonAttachment.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonAttachment.h"
#import "NSArray+Utils.h"

@implementation MACommonAttachment 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSString",
            @"name" : @"url",
            @"json_name" : @"url"
        },
        @{
            @"default" : @"View Attachment",
            @"type" : @"NSString",
            @"name" : @"linkText",
            @"json_name" : @"link_text"
        }
    ];
}


@end

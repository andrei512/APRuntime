
//
//  MACommonBrokerage.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonBrokerage : Model


//  The company s name
@property (nonatomic, strong) NSString *name;

//  The company s website url
@property (nonatomic, strong) NSString *url;

//  The company s address
@property (nonatomic, strong) NSString *address;

//  URL containing the company s logo
@property (nonatomic, strong) NSString *logoUrl;

//  The company s phone number
@property (nonatomic, strong) NSString *phone;



@end

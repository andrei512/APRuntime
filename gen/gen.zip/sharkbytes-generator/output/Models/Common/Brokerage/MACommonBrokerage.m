
//
//  MACommonBrokerage.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonBrokerage.h"
#import "NSArray+Utils.h"

@implementation MACommonBrokerage 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"name",
            @"json_name" : @"name"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"url",
            @"json_name" : @"url"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"address",
            @"json_name" : @"address"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"logoUrl",
            @"json_name" : @"logo_url"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"phone",
            @"json_name" : @"phone"
        }
    ];
}


@end

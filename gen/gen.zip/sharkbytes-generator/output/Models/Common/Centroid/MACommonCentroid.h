
//
//  MACommonCentroid.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonCentroid : Model


//  The latitude of the centroid
@property (nonatomic, strong) NSNumber *lat;

//  The longitude of the centroid
@property (nonatomic, strong) NSNumber *lng;



@end

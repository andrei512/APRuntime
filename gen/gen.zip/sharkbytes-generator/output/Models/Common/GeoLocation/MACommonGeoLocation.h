
//
//  MACommonGeoLocation.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonGeoLocation : Model


//  The viewport of the location
@property (nonatomic, strong) NSDictionary *viewport;

//  The x coordinate of the location
@property (nonatomic, strong) NSNumber *cx;

//  Unique identifier of a geo region
@property (nonatomic, strong) NSNumber *geoId;

//  The y coordinate of the location
@property (nonatomic, strong) NSNumber *cy;

//  If the accuracy is returned by the google_location then the values for this
//  attribute will be _approximate_ or _precise_ else the accuracy is _precise_
@property (nonatomic, strong) NSString *accuracy;

@property (nonatomic, strong) NSString *prettyName;



@end

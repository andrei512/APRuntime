
//
//  MACommonGeoLocation.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonGeoLocation.h"
#import "NSArray+Utils.h"

@implementation MACommonGeoLocation 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"of" : @"Common::Viewport",
            @"type" : @"NSDictionary",
            @"is_nullable" : @(1),
            @"name" : @"viewport",
            @"json_name" : @"viewport"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"cx",
            @"json_name" : @"cx"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"geoId",
            @"json_name" : @"geo_id"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"cy",
            @"json_name" : @"cy"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"accuracy",
            @"json_name" : @"accuracy"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"prettyName",
            @"json_name" : @"pretty_name"
        }
    ];
}


@end


//
//  MACommonListing.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"

#import "MACommonPriceHistory.h"
#import "MACommonAgent.h"


@interface MACommonListing : Model


//  Represents a list of photo patterns STRING A functional photo url can be
//  obtained by concatenating the photo pattern with the desired size like this
//  PATTERN_SIZE The valid sizes are _thumb_ _x_small_ _small_ _medium_
//  and _large_ Example
//  http www propertyshark com rfs_image_photo_188956622_small
@property (nonatomic, strong) NSArray *photos;

//  The hours interva for open house date
@property (nonatomic, strong) NSDictionary *openHouseTime;

//  String describing the status of the listing i e ForSale ForRent
//  Rented Sold Foreclosure etc
@property (nonatomic, strong) NSString *status;

//  The most recent open house date
@property (nonatomic, strong) NSDate *openHouseDate;

//  The listing s unique identifier in Point2 s system
@property (nonatomic, strong) NSNumber *point2Id;

//  The price currency eq _CAD_ _USD_
@property (nonatomic, strong) NSString *currency;

//  Unique identifier of a listing
@property (nonatomic, strong) NSNumber *id;

//  Flag when set to 1 means that the listing is a featured one
@property (nonatomic, strong) NSNumber *isFeatured;

//  Date of last update on listings
@property (nonatomic, strong) NSDate *imported;

//  These are some external links to a point2 email form Sending this email
//  the user requests some documents from the listing agent Array Optional
@property (nonatomic, strong) NSDictionary *attachments;

//  The listing s floorplans A list of strings Optional
@property (nonatomic, strong) NSArray *floorplans;

//  Represents the number of days since the listing is on point2homes
@property (nonatomic, strong) NSString *onP2h;

//  Flag when is set to 1 the listing is MLS certified
@property (nonatomic, strong) NSNumber *mlsCertified;

//  The listing s price history
@property (nonatomic, strong) NSArray *priceHistory;

//  Flag when is set to 1 listing is from the Canadian Real Estate Association
@property (nonatomic, strong) NSNumber *isCrea;

//  The listing s geographical latitude longitude coordinates
@property (nonatomic, strong) NSDictionary *centroid;

//  The listing s description
@property (nonatomic, strong) NSString *description;

//  The list of the agents
@property (nonatomic, strong) NSArray *agents;

//  Date of first time import of the listing
@property (nonatomic, strong) NSDate *created;

//  Represents a text manually entered by the seller for a few number of
//  listings String Optional
@property (nonatomic, strong) NSString *sellerComment;

//  Information about the property
@property (nonatomic, strong) NSDictionary *propertyInfo;

//  The price of the listing
@property (nonatomic, strong) NSNumber *price;

//  URL which must be added on the detail page for tracking purposes tracking
//  pixel could be included as image source
@property (nonatomic, strong) NSString *webBugUrl;

@property (nonatomic, strong) NSString *mlsNumber;



@end

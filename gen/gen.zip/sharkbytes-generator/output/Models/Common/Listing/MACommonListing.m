
//
//  MACommonListing.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonListing.h"
#import "NSArray+Utils.h"

@implementation MACommonListing 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"of" : @{
                @"type" : @"NSString"
            },
            @"type" : @"NSArray",
            @"name" : @"photos",
            @"json_name" : @"photos"
        },
        @{
            @"of" : @"Item",
            @"type" : @"NSDictionary",
            @"name" : @"openHouseTime",
            @"json_name" : @"open_house_time"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"status",
            @"json_name" : @"status"
        },
        @{
            @"type" : @"NSDate",
            @"is_nullable" : @(1),
            @"name" : @"openHouseDate",
            @"json_name" : @"open_house_date"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"point2Id",
            @"json_name" : @"point2_id"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"currency",
            @"json_name" : @"currency"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"id",
            @"json_name" : @"id"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"isFeatured",
            @"json_name" : @"is_featured"
        },
        @{
            @"type" : @"NSDate",
            @"name" : @"imported",
            @"json_name" : @"imported"
        },
        @{
            @"of" : @"Item",
            @"type" : @"NSDictionary",
            @"name" : @"attachments",
            @"json_name" : @"attachments"
        },
        @{
            @"of" : @{
                @"type" : @"NSString"
            },
            @"type" : @"NSArray",
            @"is_nullable" : @(1),
            @"name" : @"floorplans",
            @"json_name" : @"floorplans"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"onP2h",
            @"json_name" : @"on_p2h"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"mlsCertified",
            @"json_name" : @"mls_certified"
        },
        @{
            @"of" : @{
                @"of" : @"MACommonPriceHistory",
                @"type" : @"NSDictionary"
            },
            @"type" : @"NSArray",
            @"name" : @"priceHistory",
            @"json_name" : @"price_history"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"isCrea",
            @"json_name" : @"is_crea"
        },
        @{
            @"of" : @"Item",
            @"type" : @"NSDictionary",
            @"name" : @"centroid",
            @"json_name" : @"centroid"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"description",
            @"json_name" : @"description"
        },
        @{
            @"of" : @{
                @"of" : @"MACommonAgent",
                @"type" : @"NSDictionary"
            },
            @"type" : @"NSArray",
            @"name" : @"agents",
            @"json_name" : @"agents"
        },
        @{
            @"type" : @"NSDate",
            @"name" : @"created",
            @"json_name" : @"created"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"sellerComment",
            @"json_name" : @"seller_comment"
        },
        @{
            @"of" : @"Common::PropertyInfo",
            @"type" : @"NSDictionary",
            @"name" : @"propertyInfo",
            @"json_name" : @"property_info"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"price",
            @"json_name" : @"price"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"webBugUrl",
            @"json_name" : @"web_bug_url"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"mlsNumber",
            @"json_name" : @"mls_number"
        }
    ];
}


@end

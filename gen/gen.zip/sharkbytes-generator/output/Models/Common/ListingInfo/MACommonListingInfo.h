
//
//  MACommonListingInfo.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonListingInfo : Model


//  Date of first time import of the listing
@property (nonatomic, strong) NSDate *created;

//  String describing the status of the listing i e ForSale ForRent
//  Rented Sold Foreclosure etc
@property (nonatomic, strong) NSString *status;

//  Flag when is set to 1 the listing is MLS certified
@property (nonatomic, strong) NSNumber *mlsCertified;

//  The price of the listing
@property (nonatomic, strong) NSNumber *price;

//  Unique identifier of a listing
@property (nonatomic, strong) NSNumber *id;

//  Listing s address with street and location
@property (nonatomic, strong) NSString *address;

//  Description of the listing
@property (nonatomic, strong) NSString *description;

//  Date of last update on listings
@property (nonatomic, strong) NSDate *imported;



@end

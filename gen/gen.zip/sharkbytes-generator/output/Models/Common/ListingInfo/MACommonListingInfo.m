
//
//  MACommonListingInfo.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonListingInfo.h"
#import "NSArray+Utils.h"

@implementation MACommonListingInfo 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSDate",
            @"name" : @"created",
            @"json_name" : @"created"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"status",
            @"json_name" : @"status"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"mlsCertified",
            @"json_name" : @"mls_certified"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"price",
            @"json_name" : @"price"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"id",
            @"json_name" : @"id"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"address",
            @"json_name" : @"address"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"description",
            @"json_name" : @"description"
        },
        @{
            @"type" : @"NSDate",
            @"name" : @"imported",
            @"json_name" : @"imported"
        }
    ];
}


@end

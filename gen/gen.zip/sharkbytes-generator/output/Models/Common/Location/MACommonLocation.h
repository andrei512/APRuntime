
//
//  MACommonLocation.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonLocation : Model


//  Name of the country that the property belongs to
@property (nonatomic, strong) NSString *country;

//  Property s elementary and high school
@property (nonatomic, strong) NSString *unifiedSchoolDistrict;

//  Name of the zipcode
@property (nonatomic, strong) NSString *zipcode;

//  Property s elementary school
@property (nonatomic, strong) NSString *elementarySchoolDistrict;

//  Property s high school
@property (nonatomic, strong) NSString *highSchoolDistrict;

//  Name of the state that the property belongs to
@property (nonatomic, strong) NSString *state;

//  Name of the city that the property belongs to
@property (nonatomic, strong) NSString *city;

//  Property s address with street and location
@property (nonatomic, strong) NSString *fullAddress;

//  Name of the county that the property belongs to
@property (nonatomic, strong) NSString *county;

//  Address of the property
@property (nonatomic, strong) NSString *address;

//  Neighborhood of the property
@property (nonatomic, strong) NSString *neighborhood;



@end

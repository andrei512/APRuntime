
//
//  MACommonLocation.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonLocation.h"
#import "NSArray+Utils.h"

@implementation MACommonLocation 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSString",
            @"name" : @"country",
            @"json_name" : @"country"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"unifiedSchoolDistrict",
            @"json_name" : @"unified_school_district"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"zipcode",
            @"json_name" : @"zipcode"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"elementarySchoolDistrict",
            @"json_name" : @"elementary_school_district"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"highSchoolDistrict",
            @"json_name" : @"high_school_district"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"state",
            @"json_name" : @"state"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"city",
            @"json_name" : @"city"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"fullAddress",
            @"json_name" : @"full_address"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"county",
            @"json_name" : @"county"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"address",
            @"json_name" : @"address"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"neighborhood",
            @"json_name" : @"neighborhood"
        }
    ];
}


@end


//
//  MACommonOpenHouseTime.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonOpenHouseTime : Model


//  Hour minutes AM PM when the house closes Format 99 99 AM PM
@property (nonatomic, strong) NSString *endTime;

//  Up to 255 characters Could specify additional info appointment host
//  days of week related to the event
@property (nonatomic, strong) NSString *extraInfo;

//  Hour minutes AM PM when the house opens Format 99 99 AM PM
@property (nonatomic, strong) NSString *startTime;



@end

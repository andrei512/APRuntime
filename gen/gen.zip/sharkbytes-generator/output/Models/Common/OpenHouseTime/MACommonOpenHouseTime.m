
//
//  MACommonOpenHouseTime.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonOpenHouseTime.h"
#import "NSArray+Utils.h"

@implementation MACommonOpenHouseTime 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"endTime",
            @"json_name" : @"end_time"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"extraInfo",
            @"json_name" : @"extra_info"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"startTime",
            @"json_name" : @"start_time"
        }
    ];
}


@end

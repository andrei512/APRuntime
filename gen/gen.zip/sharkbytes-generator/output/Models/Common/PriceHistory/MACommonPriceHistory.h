
//
//  MACommonPriceHistory.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonPriceHistory : Model


//  Date when this price appeared
@property (nonatomic, strong) NSDate *created;

//  The price of the listing
@property (nonatomic, strong) NSNumber *price;

//  The price per square foot
@property (nonatomic, strong) NSNumber *pricePerSqft;



@end

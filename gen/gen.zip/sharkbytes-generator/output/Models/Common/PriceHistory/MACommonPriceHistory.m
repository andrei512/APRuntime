
//
//  MACommonPriceHistory.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonPriceHistory.h"
#import "NSArray+Utils.h"

@implementation MACommonPriceHistory 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSDate",
            @"name" : @"created",
            @"json_name" : @"created"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"price",
            @"json_name" : @"price"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"pricePerSqft",
            @"json_name" : @"price_per_sqft"
        }
    ];
}


@end

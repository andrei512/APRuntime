
//
//  MACommonPropertyInfo.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonPropertyInfo : Model


//  Unique identifier of a property
@property (nonatomic, strong) NSNumber *propkey;

@property (nonatomic, strong) NSString *buildingName;

//  The no of bathrooms
@property (nonatomic, strong) NSNumber *bathrooms;

@property (nonatomic, strong) NSString *zoning;

//  The lot size
@property (nonatomic, strong) NSNumber *lotSize;

//  The year when the property was built
@property (nonatomic, strong) NSNumber *yearBuilt;

//  The no of rooms
@property (nonatomic, strong) NSNumber *rooms;

//  The no of units
@property (nonatomic, strong) NSNumber *noOfUnits;

//  Represents the tax amount that the current owner pays considering
//  exemptions or any special charges
@property (nonatomic, strong) NSNumber *taxAmount;

//  The frontage of the property
@property (nonatomic, strong) NSNumber *frontage;

@property (nonatomic, strong) NSString *apartamentFeatures;

//  The type of the property eg _Residential_ _Single family_
@property (nonatomic, strong) NSString *propertyType;

//  The area of the property in square foot
@property (nonatomic, strong) NSNumber *sqft;

//  The location information of the property
@property (nonatomic, strong) NSDictionary *location;

@property (nonatomic, strong) NSNumber *buildingStories;

@property (nonatomic, strong) NSString *buildingType;

//  The depth of the property
@property (nonatomic, strong) NSNumber *depth;

//  Standardized sub class of the property String Optional
@property (nonatomic, strong) NSString *propertyTypeSubClass;

@property (nonatomic, strong) NSString *buildingFeatures;

@property (nonatomic, strong) NSString *marketValue;

//  The no of bedrooms
@property (nonatomic, strong) NSNumber *bedrooms;



@end

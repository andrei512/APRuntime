
//
//  MACommonPropertyInfo.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonPropertyInfo.h"
#import "NSArray+Utils.h"

@implementation MACommonPropertyInfo 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSNumber",
            @"name" : @"propkey",
            @"json_name" : @"propkey"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"buildingName",
            @"json_name" : @"building_name"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"bathrooms",
            @"json_name" : @"bathrooms"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"zoning",
            @"json_name" : @"zoning"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"lotSize",
            @"json_name" : @"lot_size"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"yearBuilt",
            @"json_name" : @"year_built"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"rooms",
            @"json_name" : @"rooms"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"noOfUnits",
            @"json_name" : @"no_of_units"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"taxAmount",
            @"json_name" : @"tax_amount"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"frontage",
            @"json_name" : @"frontage"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"apartamentFeatures",
            @"json_name" : @"apartament_features"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"propertyType",
            @"json_name" : @"property_type"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"sqft",
            @"json_name" : @"sqft"
        },
        @{
            @"of" : @"Common::Location",
            @"type" : @"NSDictionary",
            @"name" : @"location",
            @"json_name" : @"location"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"buildingStories",
            @"json_name" : @"building_stories"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"buildingType",
            @"json_name" : @"building_type"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"depth",
            @"json_name" : @"depth"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"propertyTypeSubClass",
            @"json_name" : @"property_type_sub_class"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"buildingFeatures",
            @"json_name" : @"building_features"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"marketValue",
            @"json_name" : @"market_value"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"bedrooms",
            @"json_name" : @"bedrooms"
        }
    ];
}


@end

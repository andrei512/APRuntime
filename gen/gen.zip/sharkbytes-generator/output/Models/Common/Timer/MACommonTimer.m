
//
//  MACommonTimer.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonTimer.h"
#import "NSArray+Utils.h"

@implementation MACommonTimer 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSString",
            @"name" : @"name",
            @"json_name" : @"name"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"description",
            @"json_name" : @"description"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"elapsedTime",
            @"json_name" : @"elapsed_time"
        }
    ];
}


@end

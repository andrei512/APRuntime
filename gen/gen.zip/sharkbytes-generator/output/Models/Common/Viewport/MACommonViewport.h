
//
//  MACommonViewport.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACommonViewport : Model


//  The maximum longitude
@property (nonatomic, strong) NSNumber *maxLong;

//  The maximum latitude
@property (nonatomic, strong) NSNumber *maxLat;

//  The minimum latitude
@property (nonatomic, strong) NSNumber *minLat;

//  The minimum longitude
@property (nonatomic, strong) NSNumber *minLong;



@end

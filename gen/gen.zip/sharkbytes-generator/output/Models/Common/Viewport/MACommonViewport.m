
//
//  MACommonViewport.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACommonViewport.h"
#import "NSArray+Utils.h"

@implementation MACommonViewport 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSNumber",
            @"name" : @"maxLong",
            @"json_name" : @"max_long"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"maxLat",
            @"json_name" : @"max_lat"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"minLat",
            @"json_name" : @"min_lat"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"minLong",
            @"json_name" : @"min_long"
        }
    ];
}


@end


//
//  MACriteriaCriterion.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MACriteriaCriterion : Model


//  The range operator
@property (nonatomic, strong) NSObject *range;

//  The is operator
@property (nonatomic, strong) NSObject *is;

//  the lower then operator
@property (nonatomic, strong) NSObject *lt;

//  The regex operator
@property (nonatomic, strong) NSString *regex;

//  the grater then operator
@property (nonatomic, strong) NSObject *gt;

//  the lower then or equal operator
@property (nonatomic, strong) NSObject *lte;

//  the grater then or equal operator
@property (nonatomic, strong) NSObject *gte;

//  The name of the column that the criterion is aplied on
@property (nonatomic, strong) NSString *column;



@end

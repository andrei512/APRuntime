
//
//  MACriteriaCriterion.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MACriteriaCriterion.h"
#import "NSArray+Utils.h"

@implementation MACriteriaCriterion 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSObject",
            @"name" : @"range",
            @"json_name" : @"range"
        },
        @{
            @"type" : @"NSObject",
            @"name" : @"is",
            @"json_name" : @"is"
        },
        @{
            @"type" : @"NSObject",
            @"name" : @"lt",
            @"json_name" : @"lt"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"regex",
            @"json_name" : @"regex"
        },
        @{
            @"type" : @"NSObject",
            @"name" : @"gt",
            @"json_name" : @"gt"
        },
        @{
            @"type" : @"NSObject",
            @"name" : @"lte",
            @"json_name" : @"lte"
        },
        @{
            @"type" : @"NSObject",
            @"name" : @"gte",
            @"json_name" : @"gte"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"column",
            @"json_name" : @"column"
        }
    ];
}


@end


//
//  MAInputAgentsSendEmail.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MAInputAgentsSendEmail : Model


//  Flag If is set to 1 then the email was sent from an agent s page otherwise
//  the email was sent from a listing page
@property (nonatomic, strong) NSNumber *fromAgents;

//  Message content Required
@property (nonatomic, strong) NSString *content;

@property (nonatomic, strong) NSString *apiKey;

//  The sender s last name This field is not part of the input model It is
//  set by parsing the _sender_name_ field
@property (nonatomic, strong) NSString *lastName;

//  The host address used for tracking Required in Point2 s tracking service
@property (nonatomic, strong) NSString *hostAddress;

@property (nonatomic, strong) NSNumber *debug;

//  If the message is sent from a listing this field must be set to the
//  corresponding point2_listing_id which exists only for point2 listings
@property (nonatomic, strong) NSNumber *point2ListingId;

//  The sender s full name Format firstName middleName lastName
//  Optional
@property (nonatomic, strong) NSString *senderName;

//  Message subject Required
@property (nonatomic, strong) NSString *subject;

//  Flag If is set to 1 then the sender is form Point2 Optional
@property (nonatomic, strong) NSNumber *isPoint2Agent;

//  Used to generate lead for the listings Emails are sent to this email as
//  well for tracking purposes This attribute does not needs to be sent to the
//  service s call because it will be automatically set when
//  _point2_listing_id_ attribute is sent
@property (nonatomic, strong) NSString *emailLeadGeneration;

//  The sender s email address Required
@property (nonatomic, strong) NSString *senderEmail;

//  The requested showing date in YYYY MM DD format Optional
@property (nonatomic, strong) NSDate *requestedShowingDate;

//  The agent s unique ID Required
@property (nonatomic, strong) NSNumber *agentId;

//  The host name used for tracking Required in Point2 s tracking service
@property (nonatomic, strong) NSString *hostName;

//  The sender s first name This field is not part of the input model It is
//  set by parsing the _sender_name_ field
@property (nonatomic, strong) NSString *firstName;



@end

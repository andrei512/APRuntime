
//
//  MAInputAgentsSendEmail.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAInputAgentsSendEmail.h"
#import "NSArray+Utils.h"

@implementation MAInputAgentsSendEmail 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSNumber",
            @"name" : @"fromAgents",
            @"json_name" : @"from_agents"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"content",
            @"json_name" : @"content"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"apiKey",
            @"json_name" : @"api_key"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"lastName",
            @"json_name" : @"last_name"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"hostAddress",
            @"json_name" : @"host_address"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"debug",
            @"json_name" : @"debug"
        },
        @{
            @"type" : @"NSNumber",
            @"is_nullable" : @(1),
            @"name" : @"point2ListingId",
            @"json_name" : @"point2_listing_id"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"senderName",
            @"json_name" : @"sender_name"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"subject",
            @"json_name" : @"subject"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"isPoint2Agent",
            @"json_name" : @"is_point2_agent"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"emailLeadGeneration",
            @"json_name" : @"email_lead_generation"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"senderEmail",
            @"json_name" : @"sender_email"
        },
        @{
            @"type" : @"NSDate",
            @"is_nullable" : @(1),
            @"name" : @"requestedShowingDate",
            @"json_name" : @"requested_showing_date"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"agentId",
            @"json_name" : @"agent_id"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"hostName",
            @"json_name" : @"host_name"
        },
        @{
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"firstName",
            @"json_name" : @"first_name"
        }
    ];
}


@end

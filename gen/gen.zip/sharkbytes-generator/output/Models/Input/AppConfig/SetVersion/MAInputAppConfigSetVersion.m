
//
//  MAInputAppConfigSetVersion.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAInputAppConfigSetVersion.h"
#import "NSArray+Utils.h"

@implementation MAInputAppConfigSetVersion 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"type" : @"NSNumber",
            @"name" : @"version",
            @"json_name" : @"version"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"debug",
            @"json_name" : @"debug"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"apiKey",
            @"json_name" : @"api_key"
        }
    ];
}


@end


//
//  MAInputData.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MAInputData : Model


//  Optional input argument that request extra information to be included eg
//  _total_count_ on listings services or _blogs_count_ on agents services
@property (nonatomic, strong) NSArray *extraData;

@property (nonatomic, strong) NSNumber *debug;

@property (nonatomic, strong) NSString *apiKey;



@end

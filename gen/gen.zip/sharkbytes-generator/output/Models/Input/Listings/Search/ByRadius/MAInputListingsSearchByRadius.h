
//
//  MAInputListingsSearchByRadius.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"

#import "MACriteriaCriterion.h"


@interface MAInputListingsSearchByRadius : Model


//  Country abbreviation US by default
@property (nonatomic, strong) NSString *country;

@property (nonatomic, strong) NSNumber *page;

//  Radius on which the search is made Required
@property (nonatomic, strong) NSNumber *radius;

//  The y coordinate Required
@property (nonatomic, strong) NSNumber *cy;

@property (nonatomic, strong) NSString *apiKey;

@property (nonatomic, strong) NSArray *where;

@property (nonatomic, strong) NSNumber *pageSize;

//  The x coordinate Required
@property (nonatomic, strong) NSNumber *cx;

@property (nonatomic, strong) NSArray *target;

@property (nonatomic, strong) NSDictionary *sort;

@property (nonatomic, strong) NSArray *extraData;

@property (nonatomic, strong) NSString *site;

@property (nonatomic, strong) NSNumber *debug;



@end

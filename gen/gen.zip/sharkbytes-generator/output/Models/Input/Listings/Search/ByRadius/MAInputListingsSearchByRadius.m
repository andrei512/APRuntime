
//
//  MAInputListingsSearchByRadius.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAInputListingsSearchByRadius.h"
#import "NSArray+Utils.h"

@implementation MAInputListingsSearchByRadius 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"default" : @"US",
            @"type" : @"NSString",
            @"name" : @"country",
            @"json_name" : @"country"
        },
        @{
            @"default" : @(1),
            @"type" : @"NSNumber",
            @"name" : @"page",
            @"json_name" : @"page"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"radius",
            @"json_name" : @"radius"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"cy",
            @"json_name" : @"cy"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"apiKey",
            @"json_name" : @"api_key"
        },
        @{
            @"of" : @{
                @"of" : @"MACriteriaCriterion",
                @"type" : @"NSDictionary"
            },
            @"type" : @"NSArray",
            @"name" : @"where",
            @"json_name" : @"where"
        },
        @{
            @"default" : @(10),
            @"type" : @"NSNumber",
            @"name" : @"pageSize",
            @"json_name" : @"page_size"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"cx",
            @"json_name" : @"cx"
        },
        @{
            @"of" : @{
                @"type" : @"NSString"
            },
            @"type" : @"NSArray",
            @"name" : @"target",
            @"json_name" : @"target"
        },
        @{
            @"type" : @"NSDictionary",
            @"name" : @"sort",
            @"json_name" : @"sort"
        },
        @{
            @"of" : @{
                @"type" : @"NSString"
            },
            @"type" : @"NSArray",
            @"name" : @"extraData",
            @"json_name" : @"extra_data"
        },
        @{
            @"default" : @"p2h",
            @"type" : @"NSString",
            @"is_nullable" : @(1),
            @"name" : @"site",
            @"json_name" : @"site"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"debug",
            @"json_name" : @"debug"
        }
    ];
}


@end

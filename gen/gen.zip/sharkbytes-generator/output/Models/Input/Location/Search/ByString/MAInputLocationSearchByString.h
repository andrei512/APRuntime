
//
//  MAInputLocationSearchByString.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"



@interface MAInputLocationSearchByString : Model


//  Country abbreviation US by default
@property (nonatomic, strong) NSString *country;

//  If all_matches flag is set than the service will return all locations
//  found else it will return the first location found
@property (nonatomic, strong) NSNumber *allMatches;

@property (nonatomic, strong) NSArray *extraData;

//  String identifying a geographical location Required
@property (nonatomic, strong) NSString *locationString;

@property (nonatomic, strong) NSNumber *debug;

@property (nonatomic, strong) NSString *apiKey;



@end

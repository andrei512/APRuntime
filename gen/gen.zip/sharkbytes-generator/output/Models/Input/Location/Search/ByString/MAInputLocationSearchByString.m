
//
//  MAInputLocationSearchByString.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAInputLocationSearchByString.h"
#import "NSArray+Utils.h"

@implementation MAInputLocationSearchByString 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"default" : @"US",
            @"type" : @"NSString",
            @"name" : @"country",
            @"json_name" : @"country"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"allMatches",
            @"json_name" : @"all_matches"
        },
        @{
            @"of" : @{
                @"type" : @"NSString"
            },
            @"type" : @"NSArray",
            @"name" : @"extraData",
            @"json_name" : @"extra_data"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"locationString",
            @"json_name" : @"location_string"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"debug",
            @"json_name" : @"debug"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"apiKey",
            @"json_name" : @"api_key"
        }
    ];
}


@end

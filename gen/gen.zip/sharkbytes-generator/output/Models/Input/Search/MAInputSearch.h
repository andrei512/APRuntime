
//
//  MAInputSearch.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"

#import "MACriteriaCriterion.h"


@interface MAInputSearch : Model


//  The number of results on the current page Default value 10
@property (nonatomic, strong) NSNumber *pageSize;

//  Standard sort definition The sort column will contain a list of sortable
//  columns and sort types
@property (nonatomic, strong) NSDictionary *sort;

@property (nonatomic, strong) NSArray *extraData;

//  The current page number Default value 1
@property (nonatomic, strong) NSNumber *page;

@property (nonatomic, strong) NSNumber *debug;

@property (nonatomic, strong) NSString *apiKey;

//  Standard query definition The _where_ key will contain a list of columns
//  and operators Available services that use this standard query definition
//  are presented in Criterion model s documentation
@property (nonatomic, strong) NSArray *where;



@end

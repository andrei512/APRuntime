
//
//  MAInputSearch.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAInputSearch.h"
#import "NSArray+Utils.h"

@implementation MAInputSearch 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"default" : @(10),
            @"type" : @"NSNumber",
            @"name" : @"pageSize",
            @"json_name" : @"page_size"
        },
        @{
            @"type" : @"NSDictionary",
            @"name" : @"sort",
            @"json_name" : @"sort"
        },
        @{
            @"of" : @{
                @"type" : @"NSString"
            },
            @"type" : @"NSArray",
            @"name" : @"extraData",
            @"json_name" : @"extra_data"
        },
        @{
            @"default" : @(1),
            @"type" : @"NSNumber",
            @"name" : @"page",
            @"json_name" : @"page"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"debug",
            @"json_name" : @"debug"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"apiKey",
            @"json_name" : @"api_key"
        },
        @{
            @"of" : @{
                @"of" : @"MACriteriaCriterion",
                @"type" : @"NSDictionary"
            },
            @"type" : @"NSArray",
            @"name" : @"where",
            @"json_name" : @"where"
        }
    ];
}


@end

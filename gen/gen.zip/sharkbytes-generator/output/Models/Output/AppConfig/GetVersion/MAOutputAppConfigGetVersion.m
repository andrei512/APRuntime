
//
//  MAOutputAppConfigGetVersion.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAOutputAppConfigGetVersion.h"
#import "NSArray+Utils.h"

@implementation MAOutputAppConfigGetVersion 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"of" : @{
                @"of" : @"MACommonTimer",
                @"type" : @"NSDictionary"
            },
            @"type" : @"NSArray",
            @"name" : @"serviceTimers",
            @"json_name" : @"service_timers"
        },
        @{
            @"of" : @{
                @"of" : @"MACommonTimer",
                @"type" : @"NSDictionary"
            },
            @"type" : @"NSArray",
            @"name" : @"queryTimers",
            @"json_name" : @"query_timers"
        },
        @{
            @"type" : @"NSNumber",
            @"name" : @"version",
            @"json_name" : @"version"
        }
    ];
}


@end

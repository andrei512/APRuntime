
//
//  MAOutputAppConfigSetVersion.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAOutputAppConfigSetVersion.h"
#import "NSArray+Utils.h"

@implementation MAOutputAppConfigSetVersion 

- (NSArray *)propertyMetadata {
	return @[
        @{
            @"of" : @{
                @"of" : @"MACommonTimer",
                @"type" : @"NSDictionary"
            },
            @"type" : @"NSArray",
            @"name" : @"serviceTimers",
            @"json_name" : @"service_timers"
        },
        @{
            @"of" : @{
                @"of" : @"MACommonTimer",
                @"type" : @"NSDictionary"
            },
            @"type" : @"NSArray",
            @"name" : @"queryTimers",
            @"json_name" : @"query_timers"
        },
        @{
            @"type" : @"NSString",
            @"name" : @"message",
            @"json_name" : @"message"
        }
    ];
}


@end

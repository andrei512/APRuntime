
//
//  MAOutputListingsSearchByGeoId.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Model.h"

#import "MACommonTimer.h"
#import "MACommonListing.h"


@interface MAOutputListingsSearchByGeoId : Model


@property (nonatomic, strong) NSArray *serviceTimers;

@property (nonatomic, strong) NSArray *queryTimers;

@property (nonatomic, strong) NSArray *listings;

@property (nonatomic, strong) NSNumber *totalCount;



@end

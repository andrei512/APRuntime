
//
//  MAAgentsService.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---


#import <Foundation/Foundation.h>

#import "MAAgentsSearchByGeoIdRequest.h"
#import "MAAgentsSendEmailRequest.h"
#import "MAAgentsSearchByAgentIdsRequest.h"



@interface MAAgentsService : NSObject


//  Searches for agents by one geo_id and a set of search criteria Search
//  criteria is represented by the where key and supports only agent_name
//  and brokerage columns Both columns will only work with is and regex
//  operators An optional input argument is the extra_data list with which
//  additional data can be requested Currently the only supported values are
//  _total_count_ _listings_ _listings_count_ _blogs_count_
+ (MAAgentsSearchByGeoIdRequest *)searchByGeoId:(MAInputAgentsSearchByGeoId *)input;

//  This method can be used to send an email to an agent using its ID in
//  effect enabling communication from applications that are not allowed to
//  display the agent s email address A showing can optionally be requested
//  in which case _requested_showing_date_ should contain a date in YYYY MM DD
//  format
+ (MAAgentsSendEmailRequest *)sendEmail:(MAInputAgentsSendEmail *)input;

//  Searches for agents by one or more agent ids An optional input argument is
//  the extra_data list with which additional data can be requested
//  Currently the only supported values are _listings_ _listings_count_
+ (MAAgentsSearchByAgentIdsRequest *)searchByAgentIds:(MAInputAgentsSearchByAgentIds *)input;


@end

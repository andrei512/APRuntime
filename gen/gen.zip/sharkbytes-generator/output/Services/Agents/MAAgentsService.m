
//
//  MAAgentsService.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAAgentsService.h"
#import "MAAPIConfig.h"

@implementation MAAgentsService 


+ (MAAgentsSearchByGeoIdRequest *)searchByGeoId:(MAInputAgentsSearchByGeoId *)input {	
	MAAgentsSearchByGeoIdRequest *request = [MAAgentsSearchByGeoIdRequest request];

	if ([input respondsToSelector:@selector(setApiKey:)]) {
		input.apiKey = [MAAPIConfig shared].apiKey;
	}

	request.input = input;
	request.serverBaseURL = [MAAPIConfig shared].serverBaseUrl;


	return request;
}


+ (MAAgentsSendEmailRequest *)sendEmail:(MAInputAgentsSendEmail *)input {	
	MAAgentsSendEmailRequest *request = [MAAgentsSendEmailRequest request];

	if ([input respondsToSelector:@selector(setApiKey:)]) {
		input.apiKey = [MAAPIConfig shared].apiKey;
	}

	request.input = input;
	request.serverBaseURL = [MAAPIConfig shared].serverBaseUrl;


	return request;
}


+ (MAAgentsSearchByAgentIdsRequest *)searchByAgentIds:(MAInputAgentsSearchByAgentIds *)input {	
	MAAgentsSearchByAgentIdsRequest *request = [MAAgentsSearchByAgentIdsRequest request];

	if ([input respondsToSelector:@selector(setApiKey:)]) {
		input.apiKey = [MAAPIConfig shared].apiKey;
	}

	request.input = input;
	request.serverBaseURL = [MAAPIConfig shared].serverBaseUrl;


	return request;
}



@end

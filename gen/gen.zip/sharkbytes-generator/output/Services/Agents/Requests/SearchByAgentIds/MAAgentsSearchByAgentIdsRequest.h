
//
//  MAAgentsSearchByAgentIdsRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Request.h"
#import "MAInputAgentsSearchByAgentIds.h"
#import "MAOutputAgentsSearchByAgentIds.h"

@interface MAAgentsSearchByAgentIdsRequest : Request

@property (nonatomic, strong) MAInputAgentsSearchByAgentIds *input;

@end

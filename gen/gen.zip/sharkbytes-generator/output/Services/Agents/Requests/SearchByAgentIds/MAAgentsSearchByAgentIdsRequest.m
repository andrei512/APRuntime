
//
//  MAAgentsSearchByAgentIdsRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAAgentsSearchByAgentIdsRequest.h"

@implementation MAAgentsSearchByAgentIdsRequest 

+ (instancetype)request {
    MAAgentsSearchByAgentIdsRequest *request = [super request];
    
	request.serviceName = @"agents";
	request.methodName = @"search_by_agent_ids";
	request.outputClass = [MAOutputAgentsSearchByAgentIds class];

    return request;
}

@end



//
//  MAAgentsSearchByGeoIdRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Request.h"
#import "MAInputAgentsSearchByGeoId.h"
#import "MAOutputAgentsSearchByGeoId.h"

@interface MAAgentsSearchByGeoIdRequest : Request

@property (nonatomic, strong) MAInputAgentsSearchByGeoId *input;

@end


//
//  MAAgentsSearchByGeoIdRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAAgentsSearchByGeoIdRequest.h"

@implementation MAAgentsSearchByGeoIdRequest 

+ (instancetype)request {
    MAAgentsSearchByGeoIdRequest *request = [super request];
    
	request.serviceName = @"agents";
	request.methodName = @"search_by_geo_id";
	request.outputClass = [MAOutputAgentsSearchByGeoId class];

    return request;
}

@end


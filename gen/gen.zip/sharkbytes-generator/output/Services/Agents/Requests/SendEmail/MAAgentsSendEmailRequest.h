
//
//  MAAgentsSendEmailRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Request.h"
#import "MAInputAgentsSendEmail.h"
#import "MAOutputAgentsSendEmail.h"

@interface MAAgentsSendEmailRequest : Request

@property (nonatomic, strong) MAInputAgentsSendEmail *input;

@end


//
//  MAAgentsSendEmailRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAAgentsSendEmailRequest.h"

@implementation MAAgentsSendEmailRequest 

+ (instancetype)request {
    MAAgentsSendEmailRequest *request = [super request];
    
	request.serviceName = @"agents";
	request.methodName = @"send_email";
	request.outputClass = [MAOutputAgentsSendEmail class];

    return request;
}

@end


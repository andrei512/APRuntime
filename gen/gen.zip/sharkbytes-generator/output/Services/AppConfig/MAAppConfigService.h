
//
//  MAAppConfigService.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---


#import <Foundation/Foundation.h>

#import "MAAppConfigSetVersionRequest.h"
#import "MAAppConfigGetVersionRequest.h"



@interface MAAppConfigService : NSObject


//  Sets app version to a specific number
+ (MAAppConfigSetVersionRequest *)setVersion:(MAInputAppConfigSetVersion *)input;

//  Get the version number for the app that is set using the
//  app_config set_version
+ (MAAppConfigGetVersionRequest *)getVersion:(MAInputAppConfigGetVersion *)input;


@end


//
//  MAAppConfigGetVersionRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Request.h"
#import "MAInputAppConfigGetVersion.h"
#import "MAOutputAppConfigGetVersion.h"

@interface MAAppConfigGetVersionRequest : Request

@property (nonatomic, strong) MAInputAppConfigGetVersion *input;

@end

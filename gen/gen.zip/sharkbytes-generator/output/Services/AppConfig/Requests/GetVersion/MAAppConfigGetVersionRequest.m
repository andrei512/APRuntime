
//
//  MAAppConfigGetVersionRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAAppConfigGetVersionRequest.h"

@implementation MAAppConfigGetVersionRequest 

+ (instancetype)request {
    MAAppConfigGetVersionRequest *request = [super request];
    
	request.serviceName = @"app_config";
	request.methodName = @"get_version";
	request.outputClass = [MAOutputAppConfigGetVersion class];

    return request;
}

@end



//
//  MAAppConfigSetVersionRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAAppConfigSetVersionRequest.h"

@implementation MAAppConfigSetVersionRequest 

+ (instancetype)request {
    MAAppConfigSetVersionRequest *request = [super request];
    
	request.serviceName = @"app_config";
	request.methodName = @"set_version";
	request.outputClass = [MAOutputAppConfigSetVersion class];

    return request;
}

@end


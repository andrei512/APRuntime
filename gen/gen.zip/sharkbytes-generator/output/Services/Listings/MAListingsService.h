
//
//  MAListingsService.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---


#import <Foundation/Foundation.h>

#import "MAListingsSearchByGeoIdRequest.h"
#import "MAListingsSearchByRadiusRequest.h"
#import "MAListingsSearchByViewportRequest.h"
#import "MAListingsSearchByListingIdsRequest.h"



@interface MAListingsService : NSObject



+ (MAListingsSearchByGeoIdRequest *)searchByGeoId:(MAInputListingsSearchByGeoId *)input;

//  Searches listings by one location A location is represented by _radius_ x
//  coordinate _cx_ and y coordinate _cy_ An optional input argument is the
//  extra_data list with which additional data can be requested Currently
//  the only supported value is _total_count_
+ (MAListingsSearchByRadiusRequest *)searchByRadius:(MAInputListingsSearchByRadius *)input;

//  Searches listings by one location A location is represented by _viewport_
//  a rectangle represented by its lower left min_lat min_long and upper
//  right max_lat max_long corners An optional input argument is the
//  extra_data list with which additional data can be requested Currently
//  the only supported value is _total_count_
+ (MAListingsSearchByViewportRequest *)searchByViewport:(MAInputListingsSearchByViewport *)input;

//  Searches for listings by one ore more listing id s and a set of search
//  criteria By default both regular listings and foreclosure listings are
//  targeted but this behavior can be controlled with the target variable By
//  default target listings foreclosures By calling search with
//  target foreclosures for example you can search for foreclosures
//  only
+ (MAListingsSearchByListingIdsRequest *)searchByListingIds:(MAInputListingsSearchByListingIds *)input;


@end


//
//  MAListingsService.m
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAListingsService.h"
#import "MAAPIConfig.h"

@implementation MAListingsService 


+ (MAListingsSearchByGeoIdRequest *)searchByGeoId:(MAInputListingsSearchByGeoId *)input {	
	MAListingsSearchByGeoIdRequest *request = [MAListingsSearchByGeoIdRequest request];

	if ([input respondsToSelector:@selector(setApiKey:)]) {
		input.apiKey = [MAAPIConfig shared].apiKey;
	}

	request.input = input;
	request.serverBaseURL = [MAAPIConfig shared].serverBaseUrl;


	return request;
}


+ (MAListingsSearchByRadiusRequest *)searchByRadius:(MAInputListingsSearchByRadius *)input {	
	MAListingsSearchByRadiusRequest *request = [MAListingsSearchByRadiusRequest request];

	if ([input respondsToSelector:@selector(setApiKey:)]) {
		input.apiKey = [MAAPIConfig shared].apiKey;
	}

	request.input = input;
	request.serverBaseURL = [MAAPIConfig shared].serverBaseUrl;


	return request;
}


+ (MAListingsSearchByViewportRequest *)searchByViewport:(MAInputListingsSearchByViewport *)input {	
	MAListingsSearchByViewportRequest *request = [MAListingsSearchByViewportRequest request];

	if ([input respondsToSelector:@selector(setApiKey:)]) {
		input.apiKey = [MAAPIConfig shared].apiKey;
	}

	request.input = input;
	request.serverBaseURL = [MAAPIConfig shared].serverBaseUrl;


	return request;
}


+ (MAListingsSearchByListingIdsRequest *)searchByListingIds:(MAInputListingsSearchByListingIds *)input {	
	MAListingsSearchByListingIdsRequest *request = [MAListingsSearchByListingIdsRequest request];

	if ([input respondsToSelector:@selector(setApiKey:)]) {
		input.apiKey = [MAAPIConfig shared].apiKey;
	}

	request.input = input;
	request.serverBaseURL = [MAAPIConfig shared].serverBaseUrl;


	return request;
}



@end


//
//  MAListingsSearchByGeoIdRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Request.h"
#import "MAInputListingsSearchByGeoId.h"
#import "MAOutputListingsSearchByGeoId.h"

@interface MAListingsSearchByGeoIdRequest : Request

@property (nonatomic, strong) MAInputListingsSearchByGeoId *input;

@end

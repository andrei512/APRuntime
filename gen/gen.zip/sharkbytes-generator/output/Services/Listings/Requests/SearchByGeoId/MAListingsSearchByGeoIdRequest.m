
//
//  MAListingsSearchByGeoIdRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAListingsSearchByGeoIdRequest.h"

@implementation MAListingsSearchByGeoIdRequest 

+ (instancetype)request {
    MAListingsSearchByGeoIdRequest *request = [super request];
    
	request.serviceName = @"listings";
	request.methodName = @"search_by_geo_id";
	request.outputClass = [MAOutputListingsSearchByGeoId class];

    return request;
}

@end


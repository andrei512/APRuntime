
//
//  MAListingsSearchByRadiusRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MAListingsSearchByRadiusRequest.h"

@implementation MAListingsSearchByRadiusRequest 

+ (instancetype)request {
    MAListingsSearchByRadiusRequest *request = [super request];
    
	request.serviceName = @"listings";
	request.methodName = @"search_by_radius";
	request.outputClass = [MAOutputListingsSearchByRadius class];

    return request;
}

@end


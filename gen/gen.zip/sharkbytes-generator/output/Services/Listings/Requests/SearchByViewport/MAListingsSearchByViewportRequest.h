
//
//  MAListingsSearchByViewportRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Request.h"
#import "MAInputListingsSearchByViewport.h"
#import "MAOutputListingsSearchByViewport.h"

@interface MAListingsSearchByViewportRequest : Request

@property (nonatomic, strong) MAInputListingsSearchByViewport *input;

@end

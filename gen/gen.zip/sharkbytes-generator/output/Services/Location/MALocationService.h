
//
//  MALocationService.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---


#import <Foundation/Foundation.h>

#import "MALocationSearchByStringRequest.h"



@interface MALocationService : NSObject


//  Searches for locations by a given string By default it will return the
//  first location found but multiple location can be returned if the
//  _all_matches_ flag is set to 1 It will also return the number of all
//  locations found
+ (MALocationSearchByStringRequest *)searchByString:(MAInputLocationSearchByString *)input;


@end

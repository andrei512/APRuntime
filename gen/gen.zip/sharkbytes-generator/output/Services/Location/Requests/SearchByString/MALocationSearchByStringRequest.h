
//
//  MALocationSearchByStringRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "Request.h"
#import "MAInputLocationSearchByString.h"
#import "MAOutputLocationSearchByString.h"

@interface MALocationSearchByStringRequest : Request

@property (nonatomic, strong) MAInputLocationSearchByString *input;

@end

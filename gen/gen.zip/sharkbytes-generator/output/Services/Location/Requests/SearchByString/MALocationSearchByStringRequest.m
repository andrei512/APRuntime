
//
//  MALocationSearchByStringRequest.h
//  Point2Homes
//  NOTE:
//  This class was generated with SharkBytes::Generator in 13/8/2013
//  Any manual changes will be overridden at the next generation.
// 	---

#import "MALocationSearchByStringRequest.h"

@implementation MALocationSearchByStringRequest 

+ (instancetype)request {
    MALocationSearchByStringRequest *request = [super request];
    
	request.serviceName = @"location";
	request.methodName = @"search_by_string";
	request.outputClass = [MAOutputLocationSearchByString class];

    return request;
}

@end

